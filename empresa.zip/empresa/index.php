<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa teste</title>
</head>
<body>
 <h1>Empresa Teste</h1>
 <p>
    <a href="usuarios/lista.php">Lista de usuários</a>
 </p>   
 <p>
    <a href="lista_funcionarios.php">Lista de funcionários</a>
 </p>   
 <p>
    <a href="lista_projetos.php">Lista de projetos</a>
 </p>   
</body>
</html>