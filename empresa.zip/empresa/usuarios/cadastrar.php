<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa Teste</title>
</head>
<body>
<h1>Cadastro de usuários</h1>
    <br>
    <form action="salvar_cadastro.php" method="post">
        <p>Nome</p>
        <p><input type="text" name="nome" id="nome" ></p>
        <br>
        <p>E-mail</p>
        <p><input type="text" name="email" id="email" ></p>
        <br>
        <p>Senha</p>
        <p><input type="text" name="senha" id="senha" ></p>
        <br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>